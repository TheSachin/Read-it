Books = new Mongo.Collection('books');
BlogPosts = new Meteor.Collection('posts');
